// onesignal
median.onesignal = {
    run: {
        onesignalInfo: function() {
            addCommand("median://onesignal/onesignalInfo");
        }
    },
    register: function (params){
        return addCommandCallback("median://onesignal/register", params, true);
    },
    userPrivacyConsent:{
        grant: function (){
            addCommand("median://onesignal/userPrivacyConsent/grant");
        },
        revoke: function (){
            addCommand("median://onesignal/userPrivacyConsent/revoke");
        }
    },
    tags: {
        getTags: function(params){
            return addCommandCallback("median://onesignal/tags/get", params);
        },
        setTags: function (params){
            return addCommandCallback("median://onesignal/tags/set", params);
        },
        deleteTags: function(params){
            return addCommandCallback("median://onesignal/tags/delete", params);
        }
    },
    showTagsUI: function (){
        addCommand("median://onesignal/showTagsUI");
    },
    promptLocation: function (){
        addCommand("median://onesignal/promptLocation");
    },
    iam: {
        addTrigger: function (triggers){
            if(triggers){
                var keyLocal = Object.keys(triggers)[0];
                var params = {
                    key: keyLocal,
                    value: triggers[keyLocal]
                };
                addCommand("median://onesignal/iam/addTrigger", params);
            }
        },
        addTriggers: function (params){
            addCommand("median://onesignal/iam/addTriggers", params);
        },
        removeTriggerForKey: function (key){
            var params = {key: key};
            addCommand("median://onesignal/iam/removeTriggerForKey", params);
        },
        pauseInAppMessages: function (){
            addCommand("median://onesignal/iam/pauseInAppMessages?pause=true");
        },
        resumeInAppMessages: function (){
            addCommand("median://onesignal/iam/pauseInAppMessages?pause=false");
        },
        setInAppMessageClickHandler: function (handler){
            var params = {handler: handler};
            addCommand("median://onesignal/iam/setInAppMessageClickHandler", params);
        }
    },
    externalUserId: {
        set: function (params){
            return addCommandCallback("median://onesignal/login", params);
        },
        remove: function(params){
            return addCommandCallback("median://onesignal/logout", params);
        }
    },
    login: function(externalId, params = {}) {
        params.externalId = externalId
        return addCommandCallback("median://onesignal/login", params);
    },
    logout: function() {
        return addCommandCallback("median://onesignal/logout");
    },
    onesignalInfo: function(params) {
        return addCommandCallback("median://onesignal/onesignalInfo", params);
    },
    info: function(params) {
        return addCommandCallback("median://onesignal/onesignalInfo", params);
    },
    enableForegroundNotifications: function (enabled){
        addCommand("median://onesignal/enableForegroundNotifications", { enabled });
    },
    badge: {
        set: function (count){
            var params = {count: count};
            return addCommandCallback("median://onesignal/badge/set", params);
        }
    }
};