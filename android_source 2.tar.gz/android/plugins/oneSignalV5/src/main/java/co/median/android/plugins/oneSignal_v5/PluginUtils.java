package co.median.android.plugins.oneSignal_v5;

import android.app.Activity;
import android.text.TextUtils;
import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import co.median.median_core.GoNativeActivity;
import co.median.median_core.LeanUtils;

public class PluginUtils {

    private static final String TAG = "PluginUtils";

    public static void sendCallback(Activity activity, String callback, JSONObject data) {
        if (TextUtils.isEmpty(callback)) return;
        String js = LeanUtils.createJsForCallback(callback, data);
        runJavaScript(activity, js);
    }

    public static void sendSuccessCallback(Activity activity, String callback) {
        if (TextUtils.isEmpty(callback)) return;
        try {
            JSONObject jsonCallback = new JSONObject();
            jsonCallback.put("success", true);
            String js = LeanUtils.createJsForCallback(callback, jsonCallback);
            runJavaScript(activity, js);
        } catch (JSONException e) {
            Log.e(TAG, "sendErrorCallback: ", e);
        }
    }
    public static void sendErrorCallback(Activity activity, String callback, String error) {
        if (TextUtils.isEmpty(callback)) return;
        try {
            JSONObject jsonCallback = new JSONObject();
            jsonCallback.put("success", false);
            jsonCallback.put("error", error);
            String js = LeanUtils.createJsForCallback(callback, jsonCallback);
            runJavaScript(activity, js);
        } catch (JSONException e) {
            Log.e(TAG, "sendErrorCallback: ", e);
        }
    }

    public static boolean runJavaScript(Activity activity, String js) {
        if (activity instanceof GoNativeActivity) {
            ((GoNativeActivity) activity).runJavascript(js);
            return true;
        }
        return false;
    }

    public static Map<String, String> jsonObjectToMap(JSONObject jsonObject) throws Exception {
        Map<String, String> map = new HashMap<>();

        Iterator<String> keys = jsonObject.keys();
        while(keys.hasNext()) {
            String key = keys.next();
            String value = jsonObject.getString(key);
            map.put(key, value);
        }

        return map;
    }
}
