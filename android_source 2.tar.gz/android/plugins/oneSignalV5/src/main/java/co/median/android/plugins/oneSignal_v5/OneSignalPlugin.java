package co.median.android.plugins.oneSignal_v5;

import android.app.Activity;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Log;

import com.onesignal.notifications.internal.badges.impl.shortcutbadger.ShortcutBadger;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Map;

import co.median.median_core.AppConfig;
import co.median.median_core.BaseBridgeModule;
import co.median.median_core.GoNativeActivity;
import co.median.median_core.GoNativeContext;

public class OneSignalPlugin extends BaseBridgeModule {

    private static final String TAG = OneSignalPlugin.class.getName();
    private static OneSignalManager manager;

    @Override
    public void onApplicationCreate(GoNativeContext context) {
        super.onApplicationCreate(context);
        AppConfig appConfig = AppConfig.getInstance(context);

        if (appConfig.oneSignalV5 != null && appConfig.oneSignalV5.getEnabled()) {
            // Initializes SDK
            manager = new OneSignalManager(context, appConfig.oneSignalV5);
            manager.setInjectMedianJS(appConfig.injectMedianJS);
            manager.setClearNotificationsOnLaunch(appConfig.oneSignalV5.getClearNotificationsOnLaunch());
        }
    }

    @Override
    public <T extends Activity & GoNativeActivity> void onActivityCreate(T activity, boolean isRoot) {
        super.onActivityCreate(activity, isRoot);

        if (manager == null) return;
        manager.onActivityCreate(activity);

        // Startup push prompt
        if (manager.getConfig().getAutoRegister() && AppConfig.getInstance(activity).canEvokePushRequestOnce()) {
            manager.promptForPushNotifications();
        }
    }

    @Override
    public <T extends Activity & GoNativeActivity> boolean shouldOverrideUrlLoading(T activity, Uri url, JSONObject params) {
        if (!"onesignal".equals(url.getHost())) {
            return false;
        }

        if (manager == null) {
            Log.e(TAG, "shouldOverrideUrlLoading: OneSignalV5 plugin disabled.");
            return true;
        }

        // Notification and Permissions
        if ("/promptLocation".equals(url.getPath())) {
            manager.promptLocation();
        } else if ("/userPrivacyConsent/grant".equals(url.getPath())) {
            manager.provideUserConsent(true);
        } else if ("/userPrivacyConsent/revoke".equals(url.getPath())) {
            manager.provideUserConsent(false);
        } else if ("/enableForegroundNotifications".equals(url.getPath()) && params != null) {
            manager.setShowForegroundNotifications(params.optBoolean("enabled", manager.getConfig().getShowForegroundNotification()));
        } else if ("/register".equals(url.getPath())) {
            String callback = "onesignal_register_callback";
            if (params != null) {
                callback = params.optString("callback", callback);
            }
            manager.promptForPushNotifications(activity, callback);
        }

        // User
        else if ("/login".equals(url.getPath()) && params != null) {
            String userId = params.optString("externalId");
            String callback = params.optString("callback");

            manager.loginUser(activity, userId, callback);
        } else if ("/logout".equals(url.getPath()) && params != null) {
            manager.logoutCurrentUser(activity, params.optString("callback"));
        } else if ("/onesignalInfo".equals(url.getPath())) {
            String callback = OneSignalManager.NATIVE_CALLBACK;
            if (params != null) {
                callback = params.optString("callback", OneSignalManager.NATIVE_CALLBACK);
            }
            JSONObject onesignalInfo = new JSONObject(manager.getOneSignalInfo(activity));
            PluginUtils.sendCallback(activity, callback, onesignalInfo);
        }

        // User tags
        else if ("/tags/get".equals(url.getPath()) && params != null) {
            manager.getTags(activity, params.optString("callback"));
        } else if ("/tags/set".equals(url.getPath()) && params != null) {
            JSONObject tags = params.optJSONObject("tags");
            String callback = params.optString("callback");
            try {
                if (tags == null) {
                    tags = new JSONObject(params.optString("tags"));
                }
                manager.setTags(tags);
            } catch (Exception ex) {
                Log.e(TAG, "Median OneSignal Exception", ex);
                PluginUtils.sendErrorCallback(activity, callback, ex.getMessage());
            }
        } else if ("/tags/delete".equals(url.getPath())) {
            if (params != null) {
                String callback = params.optString("callback");
                try {
                    JSONArray tags = params.optJSONArray("tags");
                    if (tags == null) {
                        try {
                            tags = new JSONArray(params.optString("tags"));
                        } catch (JSONException e) {
                            // ignore
                        }
                    }
                    manager.deleteTags(activity, tags, callback);
                } catch (Exception ex) {
                    PluginUtils.sendErrorCallback(activity, callback, ex.getMessage());
                }
            } else {
                manager.deleteAllTags();
            }
        } else if ("/showTagsUI".equals(url.getPath())) {
            manager.startSubscriptionActivity(activity);
        }

        // In-app messages
        else if ("/iam/addTrigger".equals(url.getPath()) && params != null) {
            String key = params.optString("key");
            String value = params.optString("value");
            manager.addTrigger(key, value);
        } else if ("/iam/addTriggers".equals(url.getPath()) && params != null) {
            JSONObject triggers;
            if (params.has("map")) {
                triggers = params.optJSONObject("map");
            } else {
                triggers = params;
            }
            manager.addTriggers(triggers);
        } else if ("/iam/removeTriggerForKey".equals(url.getPath()) && params != null) {
            manager.removeTrigger(params.optString("key"));
        } else if ("/iam/getTriggerValueForKey".equals(url.getPath()) && params != null) {
            // Deprecated
            // manager.getTriggerValueForKey(activity, params.optString("key"));
        } else if ("/iam/pauseInAppMessages".equals(url.getPath()) && params != null) {
            manager.pauseInAppMessages(params.optBoolean("pause"));
        } else if ("/iam/setInAppMessageClickHandler".equals(url.getPath()) && params != null) {
            manager.setInAppMessageClickHandler(activity, params.optString("handler"));
        } else if ("/badge/set".equals(url.getPath()) && params != null) {
            String callback = params.optString("callback");

            if (!ShortcutBadger.isBadgeCounterSupported(activity)) {
                PluginUtils.sendErrorCallback(activity, callback, "Feature unsupported on this device.");
                return true;
            }

            int count = params.optInt("count", -99);
            if (count == -99) {
                String countString = params.optString("count", "");
                if (!TextUtils.isEmpty(countString)) {
                    try {
                        count = Integer.parseInt(countString);
                    } catch (NumberFormatException ex) {
                        PluginUtils.sendErrorCallback(activity, callback, "Invalid number input.");
                        return true;
                    }
                } else {
                    PluginUtils.sendErrorCallback(activity, callback, "Invalid number input.");
                    return true;
                }
            }

            if (count < 0) {
                PluginUtils.sendErrorCallback(activity, callback, "Invalid number input. Please enter a non-negative value.");
                return true;
            }

            manager.setNotificationBadgeCount(activity, count);
            PluginUtils.sendSuccessCallback(activity, callback);
        }

        return true;
    }

    @Override
    public Map<String, Object> getAnalyticsProviderInfo() {
        if (manager == null) return null;
        return manager.getUserInfo();
    }

    @Override
    public <T extends Activity & GoNativeActivity> void onActivityStart(T activity) {
        if (manager != null) manager.onActivityStart();
    }

    @Override
    public <T extends Activity & GoNativeActivity> void onPageFinish(T activity, boolean doNativeBridge) {
        if (manager == null || !doNativeBridge) return;
        manager.sendNativeOneSignalInfoCallback(activity);
        manager.setPageReady(true);
    }
}
