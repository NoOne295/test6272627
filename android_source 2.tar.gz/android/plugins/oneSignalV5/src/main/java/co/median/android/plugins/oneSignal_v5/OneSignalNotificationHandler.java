package co.median.android.plugins.oneSignal_v5;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;

import androidx.annotation.NonNull;

import com.onesignal.notifications.INotification;
import com.onesignal.notifications.INotificationClickEvent;
import com.onesignal.notifications.INotificationClickListener;

import org.json.JSONObject;

import co.median.median_core.GoNativeActivity;
import co.median.median_core.LeanUtils;

public class OneSignalNotificationHandler implements INotificationClickListener {

    private static final String TAG = OneSignalNotificationHandler.class.getName();
    public static final String INTENT_TARGET_URL = "targetUrl";
    private static final String CALLBACK_PUSH_OPENED = "median_onesignal_push_opened";
    private static final String CALLBACK_PUSH_OPENED_LEGACY = "gonative_onesignal_push_opened";
    private static final String CALLBACK_PUSH_OPENED_NPM = "_median_onesignal_push_opened";
    private final Activity activity;
    private boolean isPageReady = false;
    private final boolean injectMedianJS;

    OneSignalNotificationHandler(Activity activity, boolean injectMedianJS) {
        this.activity = activity;
        this.injectMedianJS = injectMedianJS;
    }

    public void initialPageReady() {
        if (this.isPageReady || !injectMedianJS) return;
        this.isPageReady = true;
        subscribe(CALLBACK_PUSH_OPENED);
        subscribe(CALLBACK_PUSH_OPENED_LEGACY);
    }

    @Override
    public void onClick(@NonNull INotificationClickEvent iNotificationClickEvent) {

        INotification notification = iNotificationClickEvent.getNotification();

        String launchUrl = notification.getLaunchURL();
        if (launchUrl != null && !launchUrl.isEmpty()) {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(launchUrl));
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            activity.startActivity(intent);
            return;
        }

        JSONObject additionalData = notification.getAdditionalData();
        String targetUrl = LeanUtils.optString(additionalData, INTENT_TARGET_URL);

        if (!TextUtils.isEmpty(targetUrl)) {
            launchMainActivity(targetUrl);
            return;
        }

        handleNotificationDataCallback(additionalData);
    }

    private void handleNotificationDataCallback(JSONObject data) {
        if (injectMedianJS) {
            invokeCallback(CALLBACK_PUSH_OPENED, data);
            invokeCallback(CALLBACK_PUSH_OPENED_LEGACY, data);
        } else {
            invokeCallback(CALLBACK_PUSH_OPENED_NPM, data);
        }
    }

    private void subscribe(String callback) {
        if (activity == null) return;
        if (activity instanceof GoNativeActivity) {
            ((GoNativeActivity) activity).subscribeEvent(callback);
        }
    }

    private void invokeCallback(String callback, JSONObject data) {
        if (activity == null) return;
        if (activity instanceof GoNativeActivity) {
            ((GoNativeActivity) activity).invokeCallback(callback, data);
        }
    }

    private void launchMainActivity(String url) {
        if (activity == null) return;
        if (activity instanceof GoNativeActivity) {
            ((GoNativeActivity) activity).launchNotificationActivity(url);
        }
    }
}
