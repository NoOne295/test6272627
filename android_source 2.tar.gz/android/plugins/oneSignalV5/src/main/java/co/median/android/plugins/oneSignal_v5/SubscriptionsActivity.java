package co.median.android.plugins.oneSignal_v5;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.preference.CheckBoxPreference;
import androidx.preference.PreferenceCategory;
import androidx.preference.PreferenceFragmentCompat;
import androidx.preference.PreferenceManager;
import androidx.preference.PreferenceScreen;

import com.onesignal.OneSignal;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import co.median.median_core.AppConfig;
import co.median.median_core.IOUtils;


public class SubscriptionsActivity extends AppCompatActivity {
    private static final String TAG = SubscriptionsActivity.class.getName();
    private static final String sharedPrefPrefix = "oneSignalV5Tag:";
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private ProgressBar progressBar;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_subscriptions);
        progressBar = findViewById(R.id.progress);
        
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        
        try {
            String tagsJsonUrl = getIntent().getStringExtra("tagsJsonUrl");
            if (TextUtils.isEmpty(tagsJsonUrl)) {
                handleError("Error retrieving tag list", null);
                return;
            }
            
            URL url = new URL(tagsJsonUrl);
            
            loadManifest(url);
        } catch (Exception e) {
            handleError("Error retrieving tag list", e);
        }
    }
    
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        
        if (id == android.R.id.home) {
            finish();
            return true;
        } else {
            return super.onOptionsItemSelected(item);
        }
    }
    
    private void handleError(@SuppressWarnings("SameParameterValue") final String userMessage, Exception e) {
        if (e != null) {
            Log.e(TAG, e.getMessage(), e);
        }

        handler.post(() -> {
            Toast.makeText(SubscriptionsActivity.this, userMessage, Toast.LENGTH_LONG).show();
            finish();
        });
    }
    
    private void loadManifest(final URL url) {
        executor.execute(() -> {
            try {
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setInstanceFollowRedirects(true);
                conn.connect();
                int responseCode = conn.getResponseCode();
                if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) {

                    // Handle redirections
                    if (responseCode == HttpURLConnection.HTTP_MOVED_PERM ||
                            responseCode == HttpURLConnection.HTTP_MOVED_TEMP ||
                            responseCode == HttpURLConnection.HTTP_SEE_OTHER ||
                            responseCode == 307) {
                        String location = conn.getHeaderField("Location");

                        // validate location as URL
                        try {
                            new URL(location);
                        } catch (MalformedURLException ex) {
                            URL base = new URL(url.toString());
                            location = new URL(base, location).toString();
                        }
                        loadManifest(new URL(location));
                        return;
                    }
                    handleError("Error retrieving tag list, responseCode: " + responseCode, new Exception("Got status " + conn.getResponseCode() + " when downloading " + url));
                    return;
                }
                
                ByteArrayOutputStream baos;
                if (conn.getContentLength() > 0)
                    baos = new ByteArrayOutputStream(conn.getContentLength());
                else baos = new ByteArrayOutputStream();
                
                InputStream is = new BufferedInputStream(conn.getInputStream());
                IOUtils.copy(is, baos);
                is.close();
                baos.close();
                
                String json = baos.toString();
                final SubscriptionsModel model = SubscriptionsModel.fromJSONString(json);
                
                if (model == null) {
                    handleError("Error parsing JSON", new Exception("Error parsing JSON from " + url));
                    return;
                }

                Map<String, String> userTags = OneSignal.getUser().getTags();

                for (SubscriptionsModel.SubscriptionsSection section : model.sections) {
                    for (SubscriptionsModel.SubscriptionItem item : section.items) {
                        if (item.identifier != null && userTags.containsKey(item.identifier)) {
                            item.isSubscribed = true;
                        }
                    }
                }

                handler.post(() -> {
                    progressBar.setVisibility(View.GONE);
                    SubscriptionsFragment subscriptionsFragment = new SubscriptionsFragment();
                    subscriptionsFragment.setModel(model);

                    getSupportFragmentManager().beginTransaction()
                            .replace(R.id.subscriptions_fragment, subscriptionsFragment)
                            .commit();
                });
            } catch (Exception e) {
                handleError("Error retrieving tag list", e);
            }
        });
    }

    public static class SubscriptionsFragment extends PreferenceFragmentCompat{
        private SubscriptionsModel model;
        
        public void setModel(SubscriptionsModel model) {
            this.model = model;
        }
        
        @Override
        public void onCreate(@Nullable Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            Context context = getActivity();
            if (context == null) return;

            // clear all preferences we created, or else the values saved on the device override
            // what we have just retrieved from OneSignal
            SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
            SharedPreferences.Editor edit = null;
            for (String key : sharedPreferences.getAll().keySet()) {
                if (key.startsWith(sharedPrefPrefix)) {
                    if (edit == null) {
                        edit = sharedPreferences.edit();
                    }
                    
                    edit.remove(key);
                }
            }
            if (edit != null) {
                edit.apply();
            }
            
            // create the preference tree
            PreferenceScreen screen = getPreferenceManager().createPreferenceScreen(context);
            
            if (this.model != null) {
                for (SubscriptionsModel.SubscriptionsSection section : this.model.sections) {
                    PreferenceCategory category = new PreferenceCategory(context);
                    category.setTitle(section.name);
                    screen.addPreference(category);
                    
                    for (SubscriptionsModel.SubscriptionItem item : section.items) {
                        final String identifier = item.identifier;
                        CheckBoxPreference preference = new CheckBoxPreference(context);
                        preference.setTitle(item.name);
                        preference.setChecked(item.isSubscribed);
                        preference.setKey(sharedPrefPrefix + identifier);
                        preference.setOnPreferenceChangeListener((preference1, o) -> {
                            if (o instanceof Boolean && (Boolean) o) {
                                OneSignal.getUser().addTag(identifier, "1");
                            } else {
                                OneSignal.getUser().removeTag(identifier);
                            }

                            return true;
                        });
                        
                        category.addPreference(preference);
                    }
                }
            }
            
            setPreferenceScreen(screen);
        }

        @Override
        public void onCreatePreferences(@Nullable Bundle savedInstanceState, @Nullable String rootKey) {
            // do nothing
        }
    }
}