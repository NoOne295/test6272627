package co.median.android.plugins.oneSignal_v5;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.text.TextUtils;
import android.util.Log;

import com.onesignal.Continue;
import com.onesignal.OneSignal;
import com.onesignal.inAppMessages.IInAppMessageClickListener;
import com.onesignal.inAppMessages.IInAppMessagesManager;
import com.onesignal.notifications.INotificationLifecycleListener;
import com.onesignal.notifications.INotificationsManager;
import com.onesignal.notifications.internal.badges.impl.shortcutbadger.ShortcutBadger;
import com.onesignal.user.IUserManager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import co.median.median_core.GoNativeActivity;
import co.median.median_core.dto.OneSignalV5;

public class OneSignalManager {

    public static final String TAG = OneSignalManager.class.getName();
    public static String NATIVE_CALLBACK = "median_onesignal_info";
    public static String NATIVE_CALLBACK_NPM = "_median_onesignal_info";
    private OneSignalNotificationHandler notificationHandler;
    private INotificationLifecycleListener notificationLifecycleListener;

    private IInAppMessageClickListener inAppMessageClickListener;
    private UserStateCallback userStateCallback;
    private boolean isPageReady = false;
    private boolean injectMedianJS = true;
    private boolean clearNotificationsOnLaunch = false;

    private final OneSignalV5 config;

    public OneSignalManager(Context context, OneSignalV5 config) {
        this.config = config;

        // Initialize SDK
        OneSignal.initWithContext(context, config.getAppId());
        OneSignal.setConsentRequired(config.getRequiresPrivacyConsent());
    }

    public void onActivityCreate(Activity activity) {
        initNotificationHandler(activity);
        initSubscriptionObserver(activity);
        OneSignal.getUser().addObserver(userChangedState -> {
            if (userStateCallback != null)
                userStateCallback.onStateChange(userChangedState.getCurrent().getExternalId());
        });

        showForegroundNotifications(config.getShowForegroundNotification());
    }

    public void setPageReady(boolean ready) {
        this.isPageReady = ready;
        if (notificationHandler != null && ready) notificationHandler.initialPageReady();
    }

    public void setClearNotificationsOnLaunch(boolean clear) {
        this.clearNotificationsOnLaunch = clear;
    }

    public void initNotificationHandler(Activity activity) {
        this.notificationHandler = new OneSignalNotificationHandler(activity, this.injectMedianJS);
        OneSignal.getNotifications().addClickListener(notificationHandler);
    }

    public void initSubscriptionObserver(Activity activity) {
        OneSignal.getUser().getPushSubscription().addObserver(pushSubscriptionChangedState -> {
            // Called when OneSignal subscription info is updated

            // Resend info to native callback
            if (isPageReady) {
                sendNativeOneSignalInfoCallback(activity);
            }
        });
    }

    public void loginUser(Activity activity, String externalId, String callback) {
        if (TextUtils.isEmpty(externalId)) {
            PluginUtils.sendErrorCallback(activity, callback, "Invalid user id");
            return;
        }
        Log.d(TAG, "loginUser: " + externalId);

        if (externalId.equals(OneSignal.getUser().getExternalId())) {
            // user already logged in to this device
            PluginUtils.sendSuccessCallback(activity, callback);
            return;
        }

        if (!TextUtils.isEmpty(callback)) {
            this.userStateCallback = newExternalId -> activity.runOnUiThread(() -> {
                if (externalId.equals(newExternalId)) {
                    PluginUtils.sendSuccessCallback(activity, callback);
                } else {
                    PluginUtils.sendErrorCallback(activity, callback, "Failed to login user: " + externalId);
                }
            });
        }

        OneSignal.login(externalId);
    }

    public void logoutCurrentUser(Activity activity, String callback) {
        String currentUser = OneSignal.getUser().getExternalId();
        Log.d(TAG, "logoutCurrentUser: " + currentUser);
        if (TextUtils.isEmpty(currentUser)) {
            PluginUtils.sendSuccessCallback(activity, callback);
            return;
        }

        if (!TextUtils.isEmpty(callback)) {
            this.userStateCallback = externalId -> activity.runOnUiThread(() -> {
                if (TextUtils.isEmpty(externalId)) {
                    PluginUtils.sendSuccessCallback(activity, callback);
                } else {
                    PluginUtils.sendErrorCallback(activity, callback, "Failed to logout user: " + OneSignal.getUser().getExternalId());
                }
            });
        }

        OneSignal.logout();
    }

    public void setShowForegroundNotifications(boolean show) {
        this.config.setShowForegroundNotification(show);
        showForegroundNotifications(show);
    }

    public void showForegroundNotifications(boolean show) {
        INotificationsManager manager = OneSignal.getNotifications();
        if (this.notificationLifecycleListener != null) {
            manager.removeForegroundLifecycleListener(this.notificationLifecycleListener);
        }

        this.notificationLifecycleListener = event -> {
            event.preventDefault();
            if (show) {
                event.getNotification().display();
            }
        };

        manager.addForegroundLifecycleListener(this.notificationLifecycleListener);
    }

    public void promptForPushNotifications() {
        OneSignal.getNotifications().requestPermission(true, Continue.none());
    }

    public void promptForPushNotifications(Activity activity, String callback) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            OneSignal.getNotifications().requestPermission(true, Continue.with(r -> {
                if (r.isSuccess()) {
                    boolean granted = Boolean.TRUE.equals(r.getData());
                    try {
                        JSONObject jsonObject = new JSONObject();
                        jsonObject.put("isSubscribed", granted);
                        PluginUtils.sendCallback(activity, callback, jsonObject);
                    } catch (JSONException jsonException) {
                        Log.e(TAG, "promptForPushNotifications: ", jsonException);
                    }

                } else {
                    try {
                        JSONObject jsonObject = new JSONObject();
                        jsonObject.put("isSubscribed", false);
                        if (r.getThrowable() != null) {
                            jsonObject.put("error", r.getThrowable().getMessage());
                        }
                        PluginUtils.sendCallback(activity, callback, jsonObject);
                    } catch (JSONException jsonException) {
                        Log.e(TAG, "promptForPushNotifications: ", jsonException);
                    }
                }
            }));
        } else {
            OneSignal.getNotifications().requestPermission(true, Continue.none());
        }
    }

    public void setInAppMessageClickHandler(Activity activity, String handler) {
        if (TextUtils.isEmpty(handler)) return;

        IInAppMessagesManager manager = OneSignal.getInAppMessages();
        if (this.inAppMessageClickListener != null) {
            manager.removeClickListener(this.inAppMessageClickListener);
        }

        this.inAppMessageClickListener = event -> {
            HashMap<String, Object> map = new HashMap<>();
            map.put("clickName", event.getResult().getActionId());
            map.put("clickUrl", event.getResult().getUrl());
            map.put("closingMessage", event.getResult().getClosingMessage());
            JSONObject jsonObject = new JSONObject(map);
            activity.runOnUiThread(() -> PluginUtils.sendCallback(activity, handler, jsonObject));
        };

        manager.addClickListener(this.inAppMessageClickListener);
    }

    public void promptLocation() {
        OneSignal.getLocation().requestPermission(Continue.none());
    }

    public void provideUserConsent(boolean consent) {
        OneSignal.setConsentGiven(consent);
        if (consent && config.getAutoRegister()) promptForPushNotifications();
    }

    public synchronized void getTags(Activity activity, String callback) {
        if (TextUtils.isEmpty(callback)) return;
        try {
            JSONObject results = new JSONObject();
            results.put("success", true);
            results.put("tags", new JSONObject(OneSignal.getUser().getTags()));
            PluginUtils.sendCallback(activity, callback, results);
        } catch (Exception ex) {
            Log.e(TAG, "Error occurred", ex);
            PluginUtils.sendErrorCallback(activity, callback, ex.getMessage());
        }
    }

    public synchronized void setTags(JSONObject tags) {
        if (tags == null) return;
        deleteAllTags();
        try {
            OneSignal.getUser().addTags(PluginUtils.jsonObjectToMap(tags));
        } catch (Exception e) {
            Log.e(TAG, "setTags: ", e);
        }
    }

    public synchronized void deleteTags(Activity activity, JSONArray tags, String callback) {
        if (tags != null) {
            for (int i = 0; i < tags.length(); i++) {
                String tag = tags.optString(i);
                if (!TextUtils.isEmpty(tag)) {
                    OneSignal.getUser().getTags().remove(tag);
                }
            }
        } else {
            deleteAllTags();
        }
        PluginUtils.sendSuccessCallback(activity, callback);
    }

    public synchronized void deleteAllTags() {
        if (!OneSignal.getUser().getTags().isEmpty())
            OneSignal.getUser().removeTags(OneSignal.getUser().getTags().keySet());
    }

    public synchronized void addTrigger(String key, String value) {
        if (TextUtils.isEmpty(key) || TextUtils.isEmpty(value)) return;
        OneSignal.getInAppMessages().addTrigger(key, value);
    }

    public synchronized void addTriggers(JSONObject triggers) {
        if (triggers == null) return;

        try {
            OneSignal.getInAppMessages().addTriggers(PluginUtils.jsonObjectToMap(triggers));
        } catch (Exception e) {
            Log.e(TAG, "addTriggers: ", e);
        }
    }

    public synchronized void removeTrigger(String key) {
        if (TextUtils.isEmpty(key)) return;
        OneSignal.getInAppMessages().removeTrigger(key);
    }

    public void startSubscriptionActivity(Context context) {
        Intent intent = new Intent(context, SubscriptionsActivity.class);
        intent.putExtra("tagsJsonUrl", config.getTagsJsonUrl());
        context.startActivity(intent);
    }

    public void pauseInAppMessages(boolean pause) {
        OneSignal.getInAppMessages().setPaused(pause);
    }

    public void sendNativeOneSignalInfoCallback(Activity activity) {
        sendOneSignalInfo(activity, injectMedianJS ? NATIVE_CALLBACK : NATIVE_CALLBACK_NPM);
    }

    public void sendOneSignalInfo(Activity activity, String callback) {
        Map<String, Object> userInfo = getOneSignalInfo(activity);
        if (userInfo == null || userInfo.isEmpty()) return;
        PluginUtils.sendCallback(activity, callback, new JSONObject(userInfo));
    }


    public Map<String, Object> getOneSignalInfo(Activity activity) {

        Map<String, Object> userInfo = getUserInfo();

        // insert device info
        if (activity instanceof GoNativeActivity) {
            Map<String, Object> deviceInfo = ((GoNativeActivity) activity).getDeviceInfo();
            if (deviceInfo != null && !deviceInfo.isEmpty())
                userInfo.putAll(deviceInfo);
        }

        userInfo.put("legacy", false);

        return userInfo;
    }

    public Map<String, Object> getUserInfo() {
        Map<String, Object> userInfo = new HashMap<>();
        try {
            IUserManager user = OneSignal.getUser();
            userInfo.put("oneSignalId", user.getOnesignalId());
            userInfo.put("externalId", user.getExternalId());
            userInfo.put("requiresUserPrivacyConsent", OneSignal.getConsentRequired());
            userInfo.put("userConsentGiven", OneSignal.getConsentGiven());

            Map<String, Object> subscriptionInfo = new HashMap<>();
            subscriptionInfo.put("id", user.getPushSubscription().getId());
            subscriptionInfo.put("token", user.getPushSubscription().getToken());
            subscriptionInfo.put("optedIn", user.getPushSubscription().getOptedIn());
            userInfo.put("subscription", subscriptionInfo);
            return userInfo;
        } catch (Exception ex) {
            Log.e(TAG, "Error setting up user info map", ex);
        }
        return null;
    }

    public void setInjectMedianJS(boolean injectMedianJS) {
        this.injectMedianJS = injectMedianJS;
    }

    public OneSignalV5 getConfig() {
        return config;
    }


    public void onActivityStart() {
        if (this.clearNotificationsOnLaunch)
            OneSignal.getNotifications().clearAllNotifications();
    }

    public void setNotificationBadgeCount(Activity activity, int count) {
        if (count < 0) return;
        ShortcutBadger.applyCount(activity, count);
    }

    interface UserStateCallback {
        void onStateChange(String externalId);
    }
}
